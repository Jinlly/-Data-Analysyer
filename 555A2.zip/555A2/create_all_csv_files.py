import os
import pandas as pd
import numpy as np

def parse_weather_by_year(year):
    # Construct the file path for the HTML file of the given year
    file_path = f"/home/Jin/555A2/toronto_weather_1840_to_2024/toronto_weather_{year}.html"
    
    if not os.path.exists(file_path):
        print(f"File for year {year} not found.")
        return None
    
    # Read and parse the HTML file
    try:
        tables = pd.read_html(file_path)  # This returns a list of DataFrames
        if tables:
            df = tables[0]  # Assuming the first table contains the data we want
            df['year'] = year  # Add the year column
            return df
        else:
            print(f"No tables found in file for year {year}.")
            return None
    except ValueError as e:
        print(f"Error parsing HTML for year {year}: {e}")
        return None

def create_all_csv_files(start_year, end_year):
    all_data = []
    for year in range(start_year, end_year + 1):
        csv_file = f"toronto_weather_{year}.csv"
        if not os.path.exists(csv_file):
            yearly_data = parse_weather_by_year(year)
            if yearly_data is not None:
                yearly_data.to_csv(csv_file, index=False)
        all_data.append(pd.read_csv(csv_file))
    
    master_frame = pd.concat(all_data, ignore_index=True)
    master_frame.to_csv("toronto_weather_1840_to_2024.csv", index=False)
    return master_frame

if __name__ == "__main__":
    main_frame = create_all_csv_files(1840, 2024) 
    print(main_frame)
    print(main_frame.info())
    print(main_frame.shape)
    print(main_frame.describe())

